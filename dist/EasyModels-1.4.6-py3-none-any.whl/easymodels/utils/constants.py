API_URL = "https://modelzoo.co/api/"

HEADERS = {
    'accept': 'application/json, text/plain, */*',
    'referer': 'https://modelzoo.co',
    'connection': 'keep-alive',
    'content-type': 'application/json'
}